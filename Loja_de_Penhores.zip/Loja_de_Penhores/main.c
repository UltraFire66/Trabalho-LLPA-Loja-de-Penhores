#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <windows.h>
#include <string.h>
#include <time.h>

void compra(int resp1,float cart,int teste,float preco,float cart1);
void compra(int resp1,float cart,int teste,float preco,float cart1) {
system("cls");

    printf("Quanto dinheiro voc� tem na sua carteira?\nR$");
    scanf("%f",&cart);
do {
  printf("\n\n1->Ver estoque\n");
  printf("2->Sair\n");
  scanf("%i",&resp1);

 if (resp1==1){
    system("cls");
    printf("1->Pistola Colt Walker\n\n");
    printf("2->Espadas Samurai Dai-Sho\n\n");
    printf("3->Michelangelo; Silver Madonna Della Pieta\n\n");
    printf("4->Fabian Perez - El Farol\n\n");
    printf("5->Manuscrito Voynich\n\n");
    printf("6->Sair\n\n");
    scanf("%i",&resp1);
    switch (resp1){

case 1:system("cls");
    printf("\t\t\tPistola Colt Walker Original\n\n");
    Sleep(600);
    printf("O Colt Walker, as vezes chamado de Walker Colt\n");
    printf(" foi um rev�lver de a��o simples com um cilindro girat�rio\n com capacidade de seis cargas de p�lvora negra");
    printf("e balas no calibre .44 feitas de chumbo. Ele foi projetado em 1846\n");
    printf("fruto de uma colabora��o entre o Capit�o Samuel Walker e o armeiro  Samuel Colt.\n\n");
    preco=25000;
    printf("\n\npre�o:%.2f",preco);

    printf("\n\n1-> Deseja comprar?");
    printf("\n2->voltar ao estoque\n");
    scanf("%i",&resp1);
    if (resp1==1){
     system("cls");
     cart1=preco-cart;
     if(cart1>0){
        printf("Perd�o voc� n�o possui Dinheiro suficiente para executar a compra deste produto\n");
        printf("Pressione 1 para continuar");
        scanf("%i",&resp1);
     }
      else {
        printf("OK, Compra efetuada,Volte sempre\n");
        Sleep(600);
        printf("Seu dinheiro na carteira agora � de R$%.2f ",cart1*-1);
        cart=cart1;
      }

    }
      break;


      case 2:system("cls");
    printf("\t\t\tEspadas Samurai Dai-Sho s.1300\n\n");
    Sleep(600);
    printf("Este par de l�minas dos anos 1300 � conhecido como Dai-Sho ou Big Little.\n");
    printf("Eles s� teriam sido possu�dos por um Samurai de alto escal�o.\nEles foram feitos � m�o pela Escola Bingo Mihara\n");
    printf("Uma famosa escola de espadas em Ko Mihara.\nAmbas as l�minas eram mais longas em um ponto");
    printf("mas mais tarde foram encurtadas\nDevido ao estilo do per�odo Edo.\n\n");

    preco=10000;
    printf("\n\nPre�o:%.2f",preco);

    printf("\n\n1-> Deseja comprar?");
    printf("\n2->voltar ao estoque\n");
    scanf("%i",&resp1);
    if (resp1==1){
     system("cls");
     cart1=preco-cart;
     if(cart1>0){
        printf("Perd�o voc� n�o possui Dinheiro suficiente para executar a compra deste produto\n");
        printf("Pressione 1 para continuar");
        scanf("%i",&resp1);
     }
      else {
        printf("OK, Compra efetuada,Volte sempre\n");
        Sleep(600);
        printf("Seu dinheiro na carteira agora � de R$%.2f ",cart1*-1);
        cart=cart1;
      }

    }
      break;

      case 3:system("cls");
    printf("\t\t\tMichelangelo; Silver Madonna Della Pieta\n\n");
    Sleep(600);
    printf("Este � um molde exato de um tesouro da Civiliza��o Ocidental\n");
    printf("A obra-prima de Michelangelo, a  Piet� da Pieta de S�o Pedro .\n");
    printf("A escultura da Virgem Maria que enfeita o Vaticano � considerada a obra\n");
    printf("Mais perfeita de Michelangelo e � a �nica escultura que ele j� assinou.\n");
    printf("Este busto de  Madonna Della Piet�   foi encomendado pelo Vaticano\nE fundido a partir de um relevo de gesso.");


    preco=34000;
    printf("\n\nPre�o:%.2f",preco);

    printf("\n\n1-> Deseja comprar?");
    printf("\n2->voltar ao estoque\n");
    scanf("%i",&resp1);
    if (resp1==1){
     system("cls");
     cart1=preco-cart;
     if(cart1>0){
        printf("Perd�o voc� n�o possui Dinheiro suficiente para executar a compra deste produto\n");
        printf("Pressione 1 para continuar");
        scanf("%i",&resp1);
     }
      else {
        printf("OK, Compra efetuada,Volte sempre\n");
        Sleep(600);
        printf("Seu dinheiro na carteira agora � de R$%.2f ",cart1*-1);
        cart=cart1;
      }

    }
      break;

      case 4:system("cls");
    printf("\t\t\tFabian Perez - El Farol\n\n");
    Sleep(600);
    printf("Pintura � �leo");
    printf("S�rie Limitada\n");
    printf("N�mero da edi��o: 1 de 100\n");
    printf("Gicl� embelezado � m�o na tela\n");
    printf("Assinado pelo pr�prio Fabian Perez\n");


    preco=50000;
    printf("\n\nPre�o:%.2f",preco);

    printf("\n\n1-> Deseja comprar?");
    printf("\n2->voltar ao estoque\n");
    scanf("%i",&resp1);
    if (resp1==1){
     system("cls");
     cart1=preco-cart;
     if(cart1>0){
        printf("Perd�o voc� n�o possui Dinheiro suficiente para executar a compra deste produto\n");
        printf("Pressione 1 para continuar");
        scanf("%i",&resp1);
     }
      else {
        printf("OK, Compra efetuada,Volte sempre\n");
        Sleep(600);
        printf("Seu dinheiro na carteira agora � de R$%.2f ",cart1*-1);
        cart=cart1;
      }

    }
      break;

      case 5:system("cls");
    printf("\t\t\tManuscrito Voynich\n\n");
    Sleep(600);
    printf("O manuscrito Voynich foi escrito no s�culo 15 por um autor desconhecido\n");
    printf("Num idioma desconhecido, usando um alfabeto desconhecido. \n");
    printf("Algu�m escreveu 240 p�ginas de texto \nCom imagens sobre astronomia, bot�nica e biologia.\n");
    printf("O livro foi encontrado em 1912 pelo comerciante Wilfrid Voynich\n");
    printf("Em um monast�rio italiano. Desde ent�o \nLinguistas v�m estudando o misterioso idioma\n");
    printf("Mas n�o conseguiram decifrar uma s� palavra sequer.");


    preco=80000;
    printf("\n\nPre�o:%.2f",preco);

    printf("\n\n1-> Deseja comprar?");
    printf("\n2->voltar ao estoque\n");
    scanf("%i",&resp1);
    if (resp1==1){
     system("cls");
     cart1=preco-cart;
     if(cart1>0){
        printf("Perd�o voc� n�o possui Dinheiro suficiente para executar a compra deste produto\n");
        printf("Pressione 1 para continuar");
        scanf("%i",&resp1);
     }
      else {
        printf("OK, Compra efetuada,Volte sempre\n");
        Sleep(600);
        printf("Seu dinheiro na carteira agora � de R$%.2f ",cart1*-1);
        cart=cart1;
      }

    }
      break;


      case 6:break;

     default: system("cls");
     printf("Digite Um valor v�lido");
     Sleep(2000);

    }

 }

 }while (resp1!=2);



}
void penhora(float cart,int resp2,float preco,int rad,int i,float cart1,float preco1);
void penhora(float cart,int resp2,float preco,int rad,int i,float cart1,float preco1){
    system ("cls");
    printf("Quanto dinheiro voc� possui na carteira?\nR$");
    scanf("%f",&cart);
    printf("Voc� deseja penhorar seu produto por quanto?\nR$");
    scanf("%f",&preco);
    srand (time(NULL));
    rad=rand() % 2;

    switch (rad){

    case 0:system("cls");
        printf("OK,me parece um pre�o justo.");

    cart1=cart+preco;

    system("cls");
    for (i=0;i<2;i++){
    printf("Efetuando sua compra");
    Sleep(500);
    printf(".");
    Sleep(500);
    printf(".");
    Sleep(500);
    printf(".");
    Sleep(500);
    system ("cls");
    }
      printf("O valor atual na sua carteira � de R$%.2f",preco1);
      Sleep(4000);
      break;

    case 1:system("cls");
        printf("meio caro, vc n�o acha? Aceito por um desconto de 25%");
    printf("\n\n1->Aceitar");
    printf("\n\n2->Recusar\n");

     scanf("%i",&resp2);

    if(resp2==1){

         cart1=preco*0.25;
         cart=cart+cart1;
         preco1=preco-cart;
         system("cls");

          for (i=0;i<2;i++){
         printf("Efetuando sua compra");
         Sleep(500);
         printf(".");
         Sleep(500);
         printf(".");
         Sleep(500);
         printf(".");
        Sleep(500);
        system ("cls");
        }
        system("cls");
        printf("OK, Trato Feito\n\n\n");
        printf("O valor atual na sua carteira � de R$%.2f",preco1);

        break;

    }
    else {

        break;


    }

    case 2:system("cls");
        printf("Perfeito");

     cart1=cart+preco;

     system("cls");
    for (i=0;i<2;i++){
    printf("Efetuando sua compra");
    Sleep(500);
    printf(".");
    Sleep(500);
    printf(".");
    Sleep(500);
    printf(".");
    Sleep(500);
    system ("cls");
    }
     printf("O valor atual na sua carteira � de R$%.2f",preco1);
      Sleep(4000);
      break;

    }


}




int main()
{
    setlocale(LC_ALL,"Portuguese");


    int i,resp;
    float cart;

    //carregamento
    for(i=3;i<3;i++){
        printf("Carregando");
        Sleep(500);
        printf(".");
        Sleep(500);
        printf(".");
        Sleep(500);
        printf(".");
        Sleep(500);
        system ("cls");
    }


    system("cls");
    Sleep(700);
    printf("\t\t================================\n");
    Sleep(700);
    printf("\t\tBem Vindo a Loja de Penhores \n ");
    printf("\t\tThe Three Musketeers\n");
    Sleep(700);
    printf("\t\t================================\n");
    Sleep(700);
    printf("\t\t\t\tPor Caio,Diego e William");
    Sleep(2000);

    system ("cls");
    do{
    system ("cls");
    printf("\n\n1->Comprar");

    printf("\n2->Penhorar");

    printf("\n3->Sair\n\n");
    scanf("%i",&resp);

    switch (resp) {

    case 1: compra (0,0,0,0,0);
    break;

   case 2:penhora(0,0,0,0,0,0,0);

    case 3: return 0;
        break;


    default:printf("Por favor insira um valor v�lido\n");
    printf("Insira 1 para continuar");
    scanf("%i",&resp);
    }



    } while (resp!=3);


    return 0;
}
