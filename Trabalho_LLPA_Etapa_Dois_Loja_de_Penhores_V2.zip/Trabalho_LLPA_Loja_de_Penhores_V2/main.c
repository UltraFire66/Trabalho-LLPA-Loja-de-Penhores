#include <stdio.h>
#include <stdlib.h>
#include <string.h> // Biblioteca para uso de fun��es relacionadas a string.
#include <windows.h> // Biblioteca para o uso da fun��o Sleep

#define porc 0.25 //Definindo a constante.

float cart1,cart=0; // Definindo uma variavel universal para ser a carteira.



int compra ( float preco, char nomeprod [70],int verproduto); //Criando o prot�tipo da fun��o de compra.
int compra ( float preco, char nomeprod [70],int verproduto){   //Criando a fun��o de compra.

//Vari�veis.

int resp2;

printf("Preco: %.2f\n\n",preco); //Imprimindo o pre�o do produto na tela.

// Criando um menu em que o usu�rio pode escolher entre comprar o produto ou n�o.
printf("\n\n\n1-> Realizar a compra desse produto.");
printf("\n2-> Voltar aos produtos da loja.\n\n");
scanf("%d",&resp2);

switch (resp2){ //Criando um switch que recebe a resposta do menu.

case 1: // Case para inserir os comandos que ser�o feitos caso a resposta seja 1.
if (cart<preco){  // Criando um if para conferir se o pre�o do produto � maior doque o valor presente na carteira do usu�rio.
  system("cls");  //Limpando a tela.
  printf("Voce nao possui dinheiro suficiente para realizar a compra.\n\n"); //Imprimindo uma mensagem.
  system("pause");  // Pausando a tela.
  system("cls"); //Limpando a tela.
  break; //Break para sair do case.
} // Fim do if.

else{ //Else para caso o valor da carteira for maior doque o pre�o do produto.
    cart -=preco; //Subtraindo o pre�o do produto da carteira do usu�rio.
    system("cls"); //Limpando a tela
    printf("Compra realizada com sucesso, o produto sera entregue para voce na saida\n\n\n"); //Imprimindo uma mensagem.
    system ("pause"); //Pausando a tela.
    system("cls"); //Limpando a tela.
   verproduto++; //Fazendo a variavel de verifica��o dos produtos receber +1;
    break; //Break para sair do case



} // Fim do else.

case 2: break; //Case para caso a resposta do menu seja dois.
default: system("cls"); //Limpando a tela.
printf("Digite um valor valido\n\n\n"); //Imprimindo uma mensagem.
system("pause"); //Pausando a tela.
system("cls"); //Limpando a tela.
}  //Switch da pergunta inicial.

return verproduto; // Retornando o valor que est� na variavel verproduto.
} // Fim da fun��o void.

int main()
{
        //Cria��o das vari�veis.

    int resp,resp1,ver1=0,verprod[9],verpen1=-1,i,verentradapenhora=0,vernumpen=0;
    float precopen1,verpen [5],precopen[5];
    char nome [40],nomepen1 [100],nomepen [5] [100];

    //For para colocar 0 em todas as posi��es do vetor verprod.
    for (i=0;i<9;i++){
  verprod [i]=0;
}
   //For para colocar 0 em todas as posi��es do vetor verpen.
 for (i=0;i<5;i++){
  verpen [i]=0;
}

    do{ // Do para a cria��o de um loop no menu inicial.
   //Criando o menu inicial

    system("cls"); // Limpando a tela.
    printf("\n\n1-> cadastro de usuario.\n\n");
    printf("2-> comprar um produto.\n\n");
    printf("3-> penhorar um produto.\n\n");
    printf("4-> sair.\n\n");
    scanf("%d",&resp);

    switch (resp) { //Switch do menu inicial.

    case 1:  system("cls"); //Limpando a tela.

        if(ver1==0){
         printf("Insira seu nome: ");
         fflush(stdin); //Limpando o buffer do teclado.
         gets (nome); //Colocando oque o usu�rio digitar dentro da string nome.
         fflush(stdin); //Novamente limpando o buffer do teclado.
         printf("\nInsira a quantidade de dinheiro em sua carteira: R$ ");
         scanf("%f",&cart1); // Scanf para colocar oque o usu�rio inserir em cart1.
         cart+=cart1; // Fazendo cart receber cart + cart1.
         system("cls"); //Limpando a tela.
         printf("OK, usuario cadastrado com sucesso\n\n\n");


         ver1=1; // Definindo o valor de ver1 para 1.
         }
         else {
            printf("Ops, voce ja foi cadastrado. : ) \n\n\n");
         }
        system("pause"); // Pausando a tela.
        system("cls"); // Limpando a tela.
        break; // Break para sair do case.

      case 2: // Case para caso o usuario digite 2 no menu inicial.
      do { // Do para criar um loop no menu de compra.
   system("cls"); //Limpando a tela.
   printf("\nO dinheiro atual na sua carteira e de R$ %.2f\n\n",cart); // Menu de compra.
   printf("1->Pistola Colt Walker\n\n");
   printf("2->Espadas Samurai Dai-Sho\n\n");
   printf("3->Michelangelo; Silver Madonna Della Pieta\n\n");
   printf("4->Fabian Perez - El Farol\n\n");
   printf("5->Manuscrito Voynich\n\n");
   if(verpen[0]>0) // Caso o �ndice 0 do vetor verpen seja maior que zero, printa uma mensagem na tela.
    printf("6->%s\n\n",nomepen[0]);
   if(verpen[1]>0) // Caso o �ndice 1 do vetor verpen seja maior que zero, printa uma mensagem na tela.
    printf("7->%s\n\n",nomepen[1]);
   if(verpen[2]>0) // Caso o �ndice 2 do vetor verpen seja maior que zero, printa uma mensagem na tela.
    printf("8->%s\n\n",nomepen[2]);
   if(verpen[3]>0) // Caso o �ndice 3 do vetor verpen seja maior que zero, printa uma mensagem na tela.
    printf("9->%s\n\n",nomepen[3]);
   if(verpen[4]>0) // Caso o �ndice 4 do vetor verpen seja maior que zero, printa uma mensagem na tela.
    printf("10->%s\n\n",nomepen[4]);

   printf("11->Sair\n\n");
   scanf("%d",&resp1);
   switch (resp1){ // Switch do menu de compras.

   case 1: system("cls"); // Limpando a tela.
 // Criando o menu de compra do primeiro item do estoque.
    printf("\t\t\tPistola Colt Walker Original\n\n");
    Sleep(600); // Fazendo o programa parar por 0.6 segundos.
     if(verprod[0]==0){
    printf("O Colt Walker, as vezes chamado de Walker Colt\n");
    printf("foi um revolver de acao simples com um cilindro giratorio\ncom capacidade de seis cargas de polvora negra ");
    printf("e balas no calibre .44 feitas de chumbo. Ele foi projetado em 1846\n");
    printf("fruto de uma colaboracao entre o Capitao Samuel Walker e o armeiro  Samuel Colt.\n\n");
   verprod[0] =compra(500,"Pistola Colt",verprod[0]);} // Fazendo uso da fun��o compra.
    else {
        printf("Produto ja comprado, em propriedade de %s\n\n\n",nome);
        system("pause"); // Pausando a tela.

    }
    break; // Break para sair do case.

   case 2: system("cls"); // Limpando a tela.
    printf("\t\t\tEspadas Samurai Dai-Sho s.1300\n\n"); // Criando o menu de compra do segundo item do estoque.
    Sleep(600); // Fazendo o programa parar por 0.6 segundos.
     if(verprod[1]==0){
    printf("Este par de laminas dos anos 1300 e conhecido como Dai-Sho ou Big Little.\n");
    printf("Eles so teriam sido possuidos por um Samurai de alto escalao.\nEles foram feitos a m�o pela Escola Bingo Mihara\n");
    printf("Uma famosa escola de espadas em Ko Mihara.\nAmbas as laminas eram mais longas em um ponto");
    printf("mas mais tarde foram encurtadas\nDevido ao estilo do per�odo Edo.\n\n");
   verprod[1] = compra(1000,"Espadas samurai",verprod[1]);} // Fazendo uso da fun��o compra.
    else {
        printf("Produto ja comprado, em propriedade de %s\n\n\n",nome);
        system("pause"); // Pausando a tela.

    }
   break; // Break para sair do case.

   case 3: system("cls"); // Limpando a tela.
    printf("\t\t\tMichelangelo; Silver Madonna Della Pieta\n\n"); // Criando o menu de compra do terceiro item do estoque.
    Sleep(600); // Fazendo o programa parar por 0.6 segundos.
       if(verprod[2]==0){
    printf("Este e um molde exato de um tesouro da Civilizacao Ocidental\n");
    printf("A obra-prima de Michelangelo, a  Pieta da Pieta de Sao Pedro .\n");
    printf("A escultura da Virgem Maria que enfeita o Vaticano � considerada a obra\n");
    printf("Mais perfeita de Michelangelo e e a unica escultura que ele ja assinou.\n");
    printf("Este busto de  Madonna Della Pieta  foi encomendado pelo Vaticano\nE fundido a partir de um relevo de gesso.\n\n");
   verprod[2] =compra(700,"Pieta",verprod[2]);} // Fazendo uso da fun��o compra.

    else {
         printf("Produto ja comprado, em propriedade de %s\n\n\n",nome);
         system("pause"); // Pausando a tela.

    }

    break; // Break para sair do case.

   case 4: system("cls"); // Limpando a tela.
    printf("\t\t\tFabian Perez - El Farol\n\n"); // Criando o menu de compra do quarto item do estoque.
    Sleep(600); // Fazendo o programa parar por 0.6 segundos.
     if(verprod[3]==0){
    printf("Pintura a oleo");
    printf("Serie Limitada\n");
    printf("Numero da edicao: 1 de 100\n");
    printf("Gicle embelezado a m�o na tela\n");
    printf("Assinado pelo proprio Fabian Perez\n\n");
    verprod[3] =compra(1500,"El Farol",verprod[3]);} // Fazendo uso da fun��o compra.

     else {
         printf("Produto ja comprado, em propriedade de %s\n\n\n",nome);
         system("pause"); // Pausando a tela.

    }

    break; // break para sair do case.

    case 5: system("cls"); // Limpando a tela.
    printf("\t\t\tManuscrito Voynich\n\n"); // Criando o menu de compra do quinto item do estoque.
    Sleep(600); // Fazendo o programa parar por 0.6 segundos.
      if(verprod[4]==0){
    printf("O manuscrito Voynich foi escrito no seculo 15 por um autor desconhecido\n");
    printf("Num idioma desconhecido, usando um alfabeto desconhecido. \n");
    printf("Alguem escreveu 240 paginas de texto \nCom imagens sobre astronomia, botanica e biologia.\n");
    printf("O livro foi encontrado em 1912 pelo comerciante Wilfrid Voynich\n");
    printf("Em um monasterio italiano. Desde entao \nLinguistas vem estudando o misterioso idioma\n");
    printf("Mas nao conseguiram decifrar uma so palavra sequer.\n\n");
    verprod[4] =compra(3000,"Manuscrito",verprod[4]);} // Fazendo uso da fun��o compra.

     else {
         printf("Produto ja comprado, em propriedade de %s\n\n\n",nome);
         system("pause"); // Pausando a tela.

    }
    break; // Break para sair do case.
    if(verpen[0]>0){
    case 6: system("cls"); // Criando o menu de compra do primeiro produto penhorado pelo usu�rio.
   printf("\t\t\t%s\n\n",nomepen[0]);
   Sleep(600); // Fazendo o programa parar por 0.6 segundos.
     if(verprod[5]==0){
    printf("Um produto que foi penhorado por %s\n",nome);
    printf("Esta disponivel para compra com um preco 25 por cento  maior doque o de penhora\n\n");
    verprod[5] = compra(precopen[0]+(precopen[0]*porc),nomepen[0],verprod[5]); // Fazendo uso da fun��o compra.

     }
     else{
printf("Produto ja comprado, em propriedade de %s\n\n\n",nome);
system("pause"); // Pausando a tela.

}
}
break; // Break para sair do case.
 if(verpen[1]>0){
    case 7: system("cls"); // Criando o menu de compra do segundo produto penhorado pelo usu�rio.
   printf("\t\t\t%s\n\n",nomepen[1]);
   Sleep(600); // Fazendo o programa parar por 0.6 segundos.

     if(verprod[6]==0){
    printf("Um produto que foi penhorado por %s\n",nome);
    printf("Esta disponivel para compra com um preco 25 por cento maior doque o de penhora\n\n");
    verprod[6]=compra(precopen[1]+(precopen[1]*porc),nomepen[1],verprod[6]); // Fazendo uso da fun��o compra.

     }

     else{
printf("Produto ja comprado, em propriedade de %s\n\n\n",nome);
system("pause"); // Pausando a tela.

}
    }
break; // Break para sair do case.
    if(verpen[2]>0){
    case 8: system("cls"); // Criando o menu de compra do terceiro produto penhorado pelo usu�rio.
   printf("\t\t\t%s\n\n",nomepen[2]);
   Sleep(600); // Fazendo o programa parar por 0.6 segundos.

     if(verprod[7]==0){
    printf("Um produto que foi penhorado por %s\n",nome);
    printf("Esta disponivel para compra com um preco 25 por cento maior doque o de penhora\n\n");
    verprod[7]=compra(precopen[2]+(precopen[2]*porc),nomepen[2],verprod[7]); // Fazendo uso da fun��o compra.

     }

     else{
printf("Produto ja comprado, em propriedade de %s\n\n\n",nome);
system("pause"); // Pausando a tela.

}
    }
break; // Break para sair do case.
    if(verpen[3]>0){
    case 9: system("cls"); // Criando o menu  de compra do quarto produto penhorado pelo usu�rio.
   printf("\t\t\t%s\n\n",nomepen[3]);
   Sleep(600); // Fazendo o programa parar por 0.6 segundos.

     if(verprod[8]==0){
    printf("Um produto que foi penhorado por %s\n",nome);
    printf("Esta disponivel para compra com um preco 25 por cento maior doque o de penhora\n\n");
    verprod[8]=compra(precopen[3]+(precopen[3]*porc),nomepen[3],verprod[8]); // Fazendo uso da fun��o compra.

     }

     else{
printf("Produto ja comprado, em propriedade de %s\n\n\n",nome);
system("pause"); // Pausando a tela.

}
    }
break; // Break para sair do case.
    if(verpen[4]>0){
    case 10: system("cls"); // Criando o menu de compra do quinto produto penhorado pelo usu�rio.
   printf("\t\t\t%s\n\n",nomepen[4]);
   Sleep(600); // Fazendo o programa parar por 0.6 segundos.

     if(verprod[9]==0){
    printf("Um produto que foi penhorado por %s\n",nome);
    printf("Esta disponivel para compra com um preco 25 por cento maior doque o de penhora\n\n");
    verprod[9]=compra(precopen[4]+(precopen[4]*porc),nomepen[4],verprod[9]); // Fazendo uso da fun��o compra.

     }

     else{
printf("Produto ja comprado, em propriedade de %s\n\n\n",nome);
system("pause"); // Pausando a tela.

}
    }
break; // Break para sair do case.
    case 11: break; // Break para sair do case.

    default: system("cls");
    printf("Por favor, insira um numero valido\n\n\n");
    system("pause"); // Pausando a tela.
    system("cls"); // Limpando a tela.
    break; // Break para sair do default.


    } // Switch da tela de compras.

    }while (resp1!=11); // Do da tela de compras.
        break; // Break para sair do case.
     case 3: system("cls"); // Limpando a tela.
     if (verentradapenhora==0){

      printf("\nAtencao, o nosso estoque possui apenas 5 espacos para produtos novos\nSendo assim, voce so podera penhorar 5 produtos\n\n\n");
      system("pause"); // Pausando a tela.
      verentradapenhora++; // fazendo verentradapenhora receber +1;
     system("cls"); // Limpando a tela.
     }
     if (vernumpen==5){
         printf("\n\t Perdao nosso estoque esta lotado e por conta disso\n Nao estamos mais aceitando itens penhorados\n\n\n");
         system("pause"); // Pausando a tela.

        break; // Break para sair do case.

     }
     else{
     system("cls"); // Limpando a tela.
     printf("\n\t\tSeja Bem Vindo a nossa aba de penhora");
     Sleep(2000); // Fazendo o programa parar por 2 segundos.
    printf("\n\n\nPor favor, insira qual produto voce deseja penhorar: ");
    fflush(stdin); // Limpando o buffer do teclado.
    gets(nomepen1); // Guardando oque o usu�rio digitar na string nomepen1.
    fflush(stdin); // Novamente limpando o buffer do teclado.
    printf("\n\nInsira o preco do seu produto: R$ ");
    scanf("%f",&precopen1);
    if (precopen1<10000){

      printf("\n\nOK aceitamos seu produto em nossa loja, obrigado pelo negocio\n\n\n");
      system("pause"); // Limpando a tela.
      cart += precopen1; // Fazendo cart receber cart + precopen1.
      verpen1++; // Aumentando o valor de verpen1 em 1.
      precopen[verpen1]=precopen1; // Fazendo o �ndice verpen1 do vetor precopen receber precopen1.
      strcpy(nomepen [verpen1], nomepen1); // Copiando o conteudo da string nomepen1 para o �ndice verpen1 do vetor de strings nomepen.
      verpen [verpen1] ++; // Fazendo o valor do �ndice verpen1 do vetor verpen receber +1.
      vernumpen++; // Fazendo o valor de vernumpen receber +1.
       break; // Break para sair do case.


    }
     else{
     printf("\n\nDesculpe, mas nao posso aceitar esse produto por um preco tao alto : (\n\n\n");
  system("pause"); // Pausando a tela
     }

       break; // Break para sair do case.



    }

    } // Fim do switch do menu inicial.



    }while(resp!=4); // Do da tela inicial.




    return 0;
}
